﻿using TravelExpenseCalculator;
using Xunit;

namespace TestProject1
{
    public class LoadTest
    {
        [Fact]
        public void LoadTest_1000Calculations()
        {
            var calc = new ExpenseCalculator();
            var random = new Random();
            var sw = System.Diagnostics.Stopwatch.StartNew();

            for (int i = 0; i < 1000; i++)
            {
                var req = new ExpenseRequest
                {
                    Days = random.Next(1, 365),
                    DailyAllowance = random.Next(100, 5000),
                    TravelCostThere = random.Next(0, 100000),
                    TravelCostBack = random.Next(0, 100000),
                    AccommodationCosts = Enumerable.Repeat(0, random.Next(1, 365)).Select(_ => (double)random.Next(0, 10000)).ToList(),
                    AdditionalExpenses = random.Next(0, 50000)
                };
                var result = calc.Calculate(req);
                Assert.True(result.GrandTotal >= 0);
            }
            sw.Stop();
            var avg = sw.ElapsedMilliseconds / 1000.0;
            Assert.True(avg < 5); 
        }
    }
}
