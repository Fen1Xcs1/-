﻿using TravelExpenseCalculator;
using Xunit;

namespace TestProject1
{
    public class ExpenseCalculatorTests
    {
        private readonly ExpenseCalculator _calc = new();

        [Fact]
        public void Calculate_ValidRequest_ReturnsCorrectTotal()
        {
            var req = new ExpenseRequest
            {
                Days = 5,
                DailyAllowance = 700,
                TravelCostThere = 1500,
                TravelCostBack = 1500,
                AccommodationCosts = new List<double> { 2300, 2600, 2200, 2400, 2500 },
                AdditionalExpenses = 800
            };
            var result = _calc.Calculate(req);
            Assert.Equal(19200, result.GrandTotal);
        }

        [Fact]
        public void Calculate_AccommodationExceedsLimit_LimitsTo2500()
        {
            var req = new ExpenseRequest
            {
                Days = 1,
                DailyAllowance = 1000,
                TravelCostThere = 0,
                TravelCostBack = 0,
                AccommodationCosts = new List<double> { 3400 },
                AdditionalExpenses = 0
            };
            var result = _calc.Calculate(req);
            Assert.Equal(1000 + 2500, result.GrandTotal);
        }

        [Fact]
        public void Calculate_TripLongerThan30Days_Applies20PercentDiscount()
        {
            var req = new ExpenseRequest
            {
                Days = 31,
                DailyAllowance = 1000,
                TravelCostThere = 0,
                TravelCostBack = 0,
                AccommodationCosts = new List<double>(new double[31]),
                AdditionalExpenses = 0
            };
            var result = _calc.Calculate(req);
            double expected = 30 * 1000 + 1 * 800;
            Assert.Equal(expected, result.TotalPerDiem);
        }

        [Fact]
        public void Calculate_NullRequest_ThrowsArgumentNullException()
        {
            Assert.Throws<ArgumentNullException>(() => _calc.Calculate(null));
        }

        [Fact]
        public void ValidateRequest_DaysZero_ReturnsFalse()
        {
            var req = new ExpenseRequest { Days = 0 };
            Assert.False(_calc.ValidateRequest(req));
        }

        [Fact]
        public void ValidateRequest_DaysNegative_ReturnsFalse()
        {
            var req = new ExpenseRequest { Days = -5 };
            Assert.False(_calc.ValidateRequest(req));
        }

        [Fact]
        public void ValidateRequest_NegativeDailyAllowance_ReturnsFalse()
        {
            var req = new ExpenseRequest { Days = 5, DailyAllowance = -100 };
            Assert.False(_calc.ValidateRequest(req));
        }

        [Fact]
        public void ValidateRequest_MismatchedAccommodationCount_ReturnsFalse()
        {
            var req = new ExpenseRequest { Days = 5, AccommodationCosts = new List<double> { 100, 200 } };
            Assert.False(_calc.ValidateRequest(req));
        }
    }
}
