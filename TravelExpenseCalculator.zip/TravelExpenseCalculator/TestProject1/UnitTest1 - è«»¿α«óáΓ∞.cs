﻿using TravelExpenseCalculator;
using Xunit;

namespace TestProject1
{
    public class IntegrationTests
    {
        [Fact]
        public void CalculatorAndRepository_SaveAfterCalculate()
        {
            var calc = new ExpenseCalculator();
            var repo = new ExpenseRepository();
            var req = new ExpenseRequest
            {
                Days = 2,
                DailyAllowance = 1000,
                TravelCostThere = 500,
                TravelCostBack = 500,
                AccommodationCosts = new List<double> { 2000, 2000 },
                AdditionalExpenses = 100
            };
            var result = calc.Calculate(req);
            repo.SaveToHistory(req, result);

            var history = repo.ReadHistory();

            Assert.Contains("7100", history.Last());
        }

        [Fact]
        public void FullScenario_InputToSaveToHistory()
        {
            var calc = new ExpenseCalculator();
            var repo = new ExpenseRepository();
            var req = new ExpenseRequest
            {
                Days = 3,
                DailyAllowance = 700,
                TravelCostThere = 1000,
                TravelCostBack = 1000,
                AccommodationCosts = new List<double> { 2000, 2000, 2000 },
                AdditionalExpenses = 0
            };
            var result = calc.Calculate(req);
            repo.SaveToHistory(req, result);
            var history = repo.ReadHistory();
            Assert.NotEmpty(history);
        }
    }
}
