﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpenseCalculator
{
    public class ExpenseCalculator
    {
        public ExpenseResult Calculate(ExpenseRequest request)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            double perDiem = request.Days * request.DailyAllowance;
            if (request.Days > 30)
            {
                perDiem = 30 * request.DailyAllowance +
                          (request.Days - 30) * request.DailyAllowance * 0.8;
            }

            double totalTravel = request.TravelCostThere + request.TravelCostBack;

            double totalAccommodation = 0;
            foreach (var cost in request.AccommodationCosts)
            {
                totalAccommodation += cost > 2500 ? 2500 : cost;
            }

            double grandTotal = perDiem + totalTravel + totalAccommodation + request.AdditionalExpenses;

            var result = new ExpenseResult
            {
                TotalPerDiem = perDiem,
                TotalTravel = totalTravel,
                TotalAccommodationCompensated = totalAccommodation,
                TotalAdditional = request.AdditionalExpenses,
                GrandTotal = grandTotal,
                Details = $"Per diem: {perDiem}, Travel: {totalTravel}, Accommodation: {totalAccommodation}, Additional: {request.AdditionalExpenses}"
            };
            return result;
        }

        public bool ValidateRequest(ExpenseRequest request)
        {
            if (request.Days <= 0) return false;
            if (request.DailyAllowance < 0) return false;
            if (request.AccommodationCosts.Count != request.Days) return false;
            return true;
        }
    }
}
