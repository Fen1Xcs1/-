﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpenseCalculator
{
    public class ExpenseResult
    {
        public double TotalPerDiem { get; set; }
        public double TotalTravel { get; set; }
        public double TotalAccommodationCompensated { get; set; }
        public double TotalAdditional { get; set; }
        public double GrandTotal { get; set; }
        public string Details { get; set; }
    }
}
