﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpenseCalculator
{
    class Program
    {
        static void Main()
        {
            var calc = new ExpenseCalculator();
            var repo = new ExpenseRepository();

            Console.Write("Количество дней: ");
            int days = int.Parse(Console.ReadLine());
            Console.Write("суточные(руб/день): ");
            double allowance = double.Parse(Console.ReadLine());
            Console.Write("Стоимость проезда туда: ");
            double there = double.Parse(Console.ReadLine());
            Console.Write("Стоимость проезда обратно: ");
            double back = double.Parse(Console.ReadLine());

            var accom = new List<double>();
            for (int i = 1; i <= days; i++)
            {
                Console.Write($"Расходы на проживание за день {i}: ");
                accom.Add(double.Parse(Console.ReadLine()));
            }

            Console.Write("Дополнительные расходы: ");
            double additional = double.Parse(Console.ReadLine());

            var request = new ExpenseRequest
            {
                Days = days,
                DailyAllowance = allowance,
                TravelCostThere = there,
                TravelCostBack = back,
                AccommodationCosts = accom,
                AdditionalExpenses = additional
            };

            if (calc.ValidateRequest(request))
            {
                var result = calc.Calculate(request);
                Console.WriteLine($"Результат: {result.GrandTotal}");
                repo.SaveToHistory(request, result);
            }
            else
            {
                Console.WriteLine("Invalid input");
            }
        }
    }
}
