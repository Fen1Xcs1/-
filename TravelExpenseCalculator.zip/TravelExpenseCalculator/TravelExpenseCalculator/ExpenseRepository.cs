﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpenseCalculator
{
    public class ExpenseRepository
    {
        private readonly string _filePath = "history.txt";

        public void SaveToHistory(ExpenseRequest request, ExpenseResult result)
        {
            var line = $"{DateTime.Now}: {result.GrandTotal} rub | Days:{request.Days} | PerDiem:{request.DailyAllowance}";
            File.AppendAllText(_filePath, line + Environment.NewLine);
        }

        public List<string> ReadHistory()
        {
            return File.Exists(_filePath) ? File.ReadAllLines(_filePath).ToList() : new List<string>();
        }
    }
}
