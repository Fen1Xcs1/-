﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpenseCalculator
{
    public class ExpenseRequest
    {
        public ExpenseRequest()
        {
            AccommodationCosts = new List<double>();
        }

        public int Days { get; set; }
        public double DailyAllowance { get; set; }
        public double TravelCostThere { get; set; }
        public double TravelCostBack { get; set; }
        public List<double> AccommodationCosts { get; set; }
        public double AdditionalExpenses { get; set; }
    }
}
